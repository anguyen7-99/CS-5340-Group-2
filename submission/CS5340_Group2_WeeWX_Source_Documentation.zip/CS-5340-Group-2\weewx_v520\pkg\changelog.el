* Sun Oct 05 2025 Matthew Wall <mwall.weewx@gmail.com> - 5.2.0-1
- new upstream release
* Thu Jul 04 2024 Matthew Wall <mwall.weewx@gmail.com> - 5.1.0-2
- ensure weewxd runs after install
* Thu Jul 04 2024 Matthew Wall <mwall.weewx@gmail.com> - 5.1.0-1
- new upstream release
* Thu Jul 04 2024 Matthew Wall <mwall.weewx@gmail.com> - 5.1.0b6-1
- new upstream release
* Wed Jul 04 2024 Matthew Wall <mwall.weewx@gmail.com> - 5.1.0b5-2
- fix bug in the instance count
- ignore systemd presets
* Wed Jul 03 2024 Matthew Wall <mwall.weewx@gmail.com> - 5.1.0b5-1
- new upstream release
- use systemd presets
- on upgrades, do not start weewxd unless it was previously running
* Sat May 25 2024 Tom Keffer (Author of WeeWX) <tkeffer@gmail.com> - 5.1.0b4-1
- Allow multiple locales
* Sun May 05 2024 Matthew Wall <mwall.weewx@gmail.com> - 5.1.0b1-1
- fix grep invocation for /etc/default/weewx
* Sat Feb 10 2024 Matthew Wall <mwall.weewx@gmail.com> - 5.0.2-1
- new upstream release
* Sun Feb 04 2024 Matthew Wall <mwall.weewx@gmail.com> - 5.0.1-3
- fix permissions for real this time
* Sun Feb 04 2024 Matthew Wall <mwall.weewx@gmail.com> - 5.0.1-2
- set permissions on all files and directories in /etc/weewx
* Mon Jan 22 2024 Matthew Wall <mwall.weewx@gmail.com> - 5.0.1-1
- new upstream release
* Sun Jan 14 2024 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0-1
- new upstream release
* Thu Jan 11 2024 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0rc3-3
- there is no pre-built pyephem for redhat9 (as of 9.3)
* Mon Jan 08 2024 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0rc3-2
- change ownership of database and report directories unconditionally
* Sun Jan 07 2024 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0rc3-1
- new upstream release
* Fri Dec 29 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0rc2-1
- new upstream release
* Thu Dec 28 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0rc1-3
- do skins in post
- do systemd units in post
- do udev rules in post
* Tue Dec 26 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0rc1-2
- include ephem as a dependency
* Thu Dec 21 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0rc1-1
- new upstream release
* Mon Dec 18 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0b18-1
- new upstream release
* Wed Dec 13 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0b17-4
- remove bytecompiled code before removing package
- do not enable template unit
* Wed Dec 13 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0b17-3
- fix typo in config file macro name
* Wed Dec 13 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0b17-2
- do not fail if there is no systemd
- set the x bit on weewxd and weectl
* Tue Dec 12 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0b17-1
- new upstream release
* Tue Nov 28 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0b16-1
- new upstream release
* Sat Oct 28 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0b15-1
- new upstream release
* Sat May 06 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0b1-1
- new upstream release
* Sat May 06 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0a30-1
- new upstream release
* Fri May 05 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 5.0.0a29-1
- new upstream release
* Wed Feb 22 2023 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.10.2-1
- new upstream release
* Mon Jan 30 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.10.1-1
- new upstream release
* Sun Jan 29 2023 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.10.0-1
- new upstream release
* Tue Oct 25 2022 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.9.1-1
- new upstream release
* Mon Oct 24 2022 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.9.0-1
- new upstream release
* Fri Sep 30 2022 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.9.0b1-1
- new upstream release
* Sat Apr 23 2022 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.8.0-2
- new upstream release
* Thu Apr 21 2022 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.8.0-1
- new upstream release
* Tue Mar 01 2022 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.7.0-1
- new upstream release
* Thu Feb 10 2022 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.6.2-1
- new upstream release
* Thu Feb 10 2022 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.6.1-1
- new upstream release
* Fri Feb 04 2022 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.6.0-1
- new upstream release
* Sat Nov 06 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.6.0b7-1
- new upstream release
* Tue Nov 02 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.6.0b6-1
- new upstream release
* Tue Oct 05 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.6.0b3-1
- new upstream release
* Tue Sep 28 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.6.0b2-1
- new upstream release
* Fri Aug 13 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.6.0b1-1
- new upstream release
* Sun May 30 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.6.0a4-1
- new upstream release
* Mon May 24 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.6.0a3-1
- new upstream release
* Fri Apr 02 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.5.1-1
- new upstream release
* Fri Apr 02 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.5.0-1
- new upstream release
* Wed Mar 24 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.5.0b2-1
- new upstream release
* Sun Mar 21 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.5.0a3-1
- new upstream release
* Sat Mar 20 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.5.0a2-1
- new upstream release
* Mon Mar 15 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.5.0a1-1
- new upstream release
* Sat Jan 30 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.4.0-1
- new upstream release
* Mon Jan 04 2021 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.3.0-1
- new upstream release
* Sat Dec 26 2020 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.3.0b3-1
- new upstream release
* Fri Dec 18 2020 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.3.0b2-1
- new upstream release
* Mon Dec 14 2020 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.3.0b1-1
- new upstream release
* Mon Oct 26 2020 Matthew Wall <mwall@users.sourceforge.net> - 4.2.0-1
- new upstream release
* Mon Oct 26 2020 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.2.0b2-1
- new upstream release
* Fri Oct 23 2020 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.2.0b1-1
- new upstream release
* Mon Oct 19 2020 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 4.2.0a1-1
- new upstream release
* Sat May 30 2020 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.1.1-1
- new upstream release
- remove the implicitly-applied dependencies in the redhat rpms
* Mon May 25 2020 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.1.0-1
- new upstream release
* Thu Apr 30 2020 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.0.0-1
- new upstream release
* Thu Apr 09 2020 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.0.0b18-2
- fix python/python3 invocations
* Thu Apr 09 2020 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 4.0.0b18-1
- new upstream release
* Tue Mar 31 2020 Matthew Wall <mwall@users.sourceforge.net> - 4.0.0b17-1
- new upstream release
* Wed Feb 26 2020 Matthew Wall <mwall@users.sourceforge.net> - 4.0.0b13-1
- new upstream release
* Sun Feb 02 2020 Matthew Wall <mwall@users.sourceforge.net> - 4.0.0b11-1
- new upstream release
* Sat Jan 04 2020 Matthew Wall <mwall@users.sourceforge.net> - 4.0.0b6-1
- new upstream release
* Sun Jul 14 2019 [ultimate] Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.9.2-1
- new upstream release
* Wed Feb 06 2019 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.9.1-2
- fix html_root location for suse
* Wed Feb 06 2019 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.9.1-1
- new upstream release
* Tue Feb 05 2019 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.9.0-1
- new upstream release
* Mon Jan 28 2019 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.9.0b3-1
- new upstream release
* Sat Jan 26 2019 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.9.0b2-1
- new upstream release
* Tue Jan 22 2019 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.9.0b1-1
- new upstream release
* Thu Aug 16 2018 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.8.2-1
- new upstream release
* Fri Jun 22 2018 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.8.1-1
- new upstream release
* Tue Nov 21 2017 mwall <mwall@users.sourceforge.net> - 3.8.0-1
- new upstream release
* Tue Nov 21 2017 mwall <mwall@users.sourceforge.net> - 3.8.0a2-1
- new upstream release
* Wed Mar 22 2017 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.7.1-1
- new upstream release
* Fri Mar 10 2017 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.7.0-1
- new upstream release
* Sat Mar 04 2017 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.7.0b3-1
- new upstream release
* Sat Feb 18 2017 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.7.0b2-1
- new upstream release
* Thu Feb 09 2017 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.7.0a3-1
- new upstream release
* Thu Oct 13 2016 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.6.1-1
- new upstream release
* Fri Oct 07 2016 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.6.0-1
- new upstream release
* Tue Oct 04 2016 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 3.6.0b3-1
- new upstream release
* Mon Sep 26 2016 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.6.0b2-1
- new upstream release
* Sun Sep 25 2016 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.6.0b1-1
- new upstream release
* Thu Sep 22 2016 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.6.0a1-1
- new upstream release
* Sun Mar 13 2016 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.5.0-1
- new upstream release
* Sat Jan 16 2016 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.4.0-1
- new upstream release
* Sun Dec 06 2015 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.3.1-1
- new upstream release
* Sat Dec 05 2015 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.3.0-1
- new upstream release
* Sat Oct 31 2015 mwall <mwall@picodeb8> - 3.3.0b1-1
- new upstream release
* Sat Jul 18 2015 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.2.1-1
- new upstream release
* Wed Jul 15 2015 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.2.0-1
- new upstream release
* Wed Jul 15 2015 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 3.2.0-1
- new upstream release
* Wed Jul 15 2015 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.2.0b3-1
- new upstream release
* Tue Jul 07 2015 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.2.0b1-1
- new upstream release
- fixes to rpm pre/post scripts in weewx.spec
* Sun Jul 05 2015 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.2.0a4-1
- new upstream release
* Sat Apr 25 2015 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.2.0a1-1
- new upstream release
- use unified wee_X utilities
* Thu Feb 05 2015 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.1.0-1
- new upstream release
* Sat Dec 06 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.0.1-1
- new upstream release
* Fri Dec 05 2014 Thomas Keffer (Author of weewx) <tkeffer@gmail.com> - 3.0.0-1
- new upstream release
* Mon Dec 01 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.0.0b2-1
- new upstream release
* Sat Nov 29 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.0.0a5-1
- new upstream release
* Sat Nov 29 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.0.0a4-1
- new upstream release
* Fri Nov 28 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.0.0a3-1
- new upstream release
* Thu Nov 27 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 3.0.0a2-1
- new upstream release
* Sat Oct 11 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 2.7.0-1
- new upstream release
* Mon Jun 16 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 2.6.4-1
- new upstream release
- added cc3000, ultimeter, ws1 drivers
* Thu Apr 10 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 2.6.3-1
- new upstream release
* Sun Feb 16 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 2.6.2-1
- new upstream release
* Sat Feb 08 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 2.6.1-1
- new upstream release
* Fri Feb 07 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 2.6.0-1
- new upstream release
* Wed Feb 05 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 2.6.0b2-1
- new upstream release
* Tue Feb 04 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 2.6.0b1-1
- new upstream release
* Tue Jan 28 2014 Matthew Wall (weewx) <mwall@users.sourceforge.net> - 2.6.0a6-1
- new upstream release
* Mon Dec 30 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.5.1-1
- added ws23xx and te923 drivers
* Tue Oct 29 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.5.0-1
- new upstream release
* Sat Oct 19 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.5.0b3-1
- new upstream release
* Fri Oct 18 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.5.0b2-1
- new upstream release
* Sat Oct 12 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.5.0b1-1
- new upstream release
* Sun Aug 04 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.4.0-1
- new upstream release
* Sat Jun 22 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.3.3-1
- new upstream release
* Sun Jun 16 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.3.2-1
- new upstream release
* Mon Apr 15 2013 Thomas Keffer <tkeffer@gmail.com> - 2.3.1-1
- new upstream release
* Tue Apr 09 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.3.0-1
- new upstream release
* Fri Feb 15 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.2.1-1
- fixed ordinals
* Thu Feb 14 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.2.0-1
- no packaging changes for the 2.2.0 release
* Wed Feb 13 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.2.0b2-1
- second beta for 2.2.0
* Sun Feb 10 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.2.0b1-1
- first beta for 2.2.0
* Sat Feb 09 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.2.0a5-1
- fixed postrm to work with ubuntu systems
* Fri Feb 08 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.2.0a4-1
- include logrotate and syslog snippets
- use wee_config_* naming
* Sun Feb 03 2013 Matthew Wall <mwall@users.sourceforge.net> - 2.2.0a3-1
- removed apache dependencies
- put generated html in /var/www/html/weewx
* Mon Jan 28 2013 Matthew Wall <mwall at users.sourceforge.net> - 2.2.0a2-1
- merged packaging branch to trunk
- put chkconfig in preun rather than postun as per rpmlint suggestion
* Sat Jan 26 2013 Matthew Wall <mwall at users.sourceforge.net> - 2.1.1-1
- initial redhat package
