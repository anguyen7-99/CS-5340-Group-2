# WMR9x8 {id=wmr9x8_notes}

The station includes a data logger, but the driver does not read records from the station.

The station emits partial packets, which may confuse some online services.

## Configuring with `weectl device` {id=wmr9x8_configuration}

The WMR9x8 stations cannot be configured with the utility
[`weectl device`](../utilities/weectl-device.md).


## Station data {id=wmr9x8_data}

The following table shows which data are provided by the station hardware and which are calculated
by WeeWX.

<table class='station_data'>
    <caption>WMR9x8 station data</caption>
    <tbody class='code'>
    <tr class="first_row">
        <td style='width:200px'>Database Field</td>
        <td>Observation</td>
        <td>Loop</td>
        <td>Archive</td>
    </tr>
    <tr>
        <td class='first_col'>barometer</td>
        <td>barometer</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>pressure</td>
        <td>pressure</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>altimeter</td>
        <td></td>
        <td>S</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>inTemp</td>
        <td>temperature_in</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>outTemp</td>
        <td>temperature_out</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>inHumidity</td>
        <td>humidity_in</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>outHumidity</td>
        <td>humidity_out</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>windSpeed</td>
        <td>wind_speed</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>windDir</td>
        <td>wind_dir</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>windGust</td>
        <td>wind_gust</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>windGustDir</td>
        <td>wind_gust_dir</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>rain</td>
        <td>rain</td>
        <td>D</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'></td>
        <td>rain_total</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>rainRate</td>
        <td>rain_rate</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>inDewpoint</td>
        <td>dewpoint_in</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>dewpoint</td>
        <td>dewpoint_out</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>windchill</td>
        <td>windchill</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>heatindex</td>
        <td></td>
        <td>S</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>UV</td>
        <td>uv</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraTemp1</td>
        <td>temperature_1</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraTemp2</td>
        <td>temperature_2</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraTemp3</td>
        <td>temperature_3</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraTemp4</td>
        <td>temperature_4</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraTemp5</td>
        <td>temperature_5</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraTemp6</td>
        <td>temperature_6</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraTemp7</td>
        <td>temperature_7</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraTemp8</td>
        <td>temperature_8</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraHumid1</td>
        <td>humidity_1</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraHumid2</td>
        <td>humidity_3</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraHumid3</td>
        <td>humidity_3</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraHumid4</td>
        <td>humidity_4</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraHumid5</td>
        <td>humidity_5</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraHumid6</td>
        <td>humidity_6</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraHumid7</td>
        <td>humidity_7</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraHumid8</td>
        <td>humidity_8</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>inTempBatteryStatus</td>
        <td>battery_status_in</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>outTempBatteryStatus</td>
        <td>battery_status_out</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>rainBatteryStatus</td>
        <td>rain_battery_status</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>windBatteryStatus</td>
        <td>wind_battery_status</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraBatteryStatus1</td>
        <td>battery_status_1</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraBatteryStatus2</td>
        <td>battery_status_2</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraBatteryStatus3</td>
        <td>battery_status_3</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraBatteryStatus4</td>
        <td>battery_status_4</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraBatteryStatus5</td>
        <td>battery_status_5</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraBatteryStatus6</td>
        <td>battery_status_6</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraBatteryStatus7</td>
        <td>battery_status_7</td>
        <td>H</td>
        <td></td>
    </tr>
    <tr>
        <td class='first_col'>extraBatteryStatus8</td>
        <td>battery_status_8</td>
        <td>H</td>
        <td></td>
    </tr>
    </tbody>
</table>
<p class='station_data_key'>
    Each packet contains a subset of all possible readings. For
    example, a temperature packet contains
    <span class='code'>temperature_N</span> and
    <span class='code'>battery_status_N</span>, a rain packet contains
    <span class='code'>rain_total</span> and
    <span class='code'>rain_rate</span>.
</p>

<p class='station_data_key'>
    <b>H</b> indicates data provided by <b>H</b>ardware<br/>
    <b>D</b> indicates data calculated by the <b>D</b>river<br/>
    <b>S</b> indicates data calculated by the StdWXCalculate <b>S</b>ervice<br/>
</p>

